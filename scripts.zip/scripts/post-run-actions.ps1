param(
    [Parameter(Mandatory = $true)]
    [int]$BaseExitCode,

    [Parameter(Mandatory = $true)]
    [string]$CollectionPath,

    [Parameter(Mandatory = $true)]
    [string]$JsonReport,

    [Parameter(Mandatory = $true)]
    [string]$HtmlReport,

    [Parameter(Mandatory = $true)]
    [string]$XlsxReport,

    [Parameter(Mandatory = $false)]
    [string]$MailEnabled = "0",

    [Parameter(Mandatory = $false)]
    [string]$SmtpServer,

    [Parameter(Mandatory = $false)]
    [int]$SmtpPort = 25,

    [Parameter(Mandatory = $false)]
    [string]$UseSsl = "false",

    [Parameter(Mandatory = $false)]
    [string]$From,

    [Parameter(Mandatory = $false)]
    [string]$To,

    [Parameter(Mandatory = $false)]
    [string]$Cc,

    [Parameter(Mandatory = $false)]
    [string]$SubjectPrefix = "[Angular_NF_API_Testing]",

    [Parameter(Mandatory = $false)]
    [string]$StartTime,

    [Parameter(Mandatory = $false)]
    [string]$LogFile,

    [Parameter(Mandatory = $false)]
    [string]$SmtpUsername,

    [Parameter(Mandatory = $false)]
    [string]$SmtpPassword,

    [Parameter(Mandatory = $false)]
    [switch]$AttachLogFile
)

$ErrorActionPreference = "Stop"

function Convert-ToBool {
    param(
        [string]$Value,
        [bool]$DefaultValue = $false
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $DefaultValue
    }

    switch ($Value.Trim().ToLowerInvariant()) {
        "1" { return $true }
        "true" { return $true }
        "yes" { return $true }
        "y" { return $true }
        "0" { return $false }
        "false" { return $false }
        "no" { return $false }
        "n" { return $false }
        default { return $DefaultValue }
    }
}

function New-HtmlReportFromJson {
    param(
        [string]$JsonPath,
        [string]$HtmlPath
    )

    if (-not (Test-Path -LiteralPath $JsonPath)) {
        throw "JSON report not found: $JsonPath"
    }

    $data = Get-Content -LiteralPath $JsonPath -Raw | ConvertFrom-Json
    $run = $data.run
    $stats = $run.stats
    $failures = @($run.failures)

    $iterationsTotal = [int64]$stats.iterations.total
    $iterationsFailed = [int64]$stats.iterations.failed
    $requestsTotal = [int64]$stats.requests.total
    $requestsFailed = [int64]$stats.requests.failed
    $assertionsTotal = [int64]$stats.assertions.total
    $assertionsFailed = [int64]$stats.assertions.failed

    $passPercent = 0
    if ($assertionsTotal -gt 0) {
        $passPercent = [math]::Round((($assertionsTotal - $assertionsFailed) * 100.0) / $assertionsTotal, 2)
    }

    $durationMs = [int64]$run.timings.completed - [int64]$run.timings.started
    $durationSec = [math]::Round($durationMs / 1000.0, 2)

    $statusText = if ($assertionsFailed -eq 0 -and $requestsFailed -eq 0) { "SUCCESS" } else { "FAILED" }
    $statusClass = if ($statusText -eq "SUCCESS") { "ok" } else { "bad" }

    $failureRows = ""
    if ($failures.Count -gt 0) {
        foreach ($f in $failures) {
            $source = ""
            if ($f.source -and $f.source.name) {
                $source = [string]$f.source.name
            }
            $errorText = ""
            if ($f.error -and $f.error.message) {
                $errorText = [string]$f.error.message
            }
            $source = [System.Net.WebUtility]::HtmlEncode($source)
            $errorText = [System.Net.WebUtility]::HtmlEncode($errorText)
            $failureRows += "<tr><td>$source</td><td>$errorText</td></tr>`n"
        }
    }
    else {
        $failureRows = "<tr><td colspan='2'>No failures</td></tr>"
    }

    $generatedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")

    $html = @"
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Fund Profile API Report</title>
  <style>
    body { font-family: Segoe UI, Arial, sans-serif; margin: 24px; background: #f7f9fc; color: #1f2937; }
    .wrap { max-width: 1080px; margin: 0 auto; }
    .header { background: #fff; border: 1px solid #dbe2ea; border-radius: 10px; padding: 16px 20px; margin-bottom: 16px; }
    .status { font-weight: 700; }
    .status.ok { color: #0f7b0f; }
    .status.bad { color: #b91c1c; }
    .grid { display: grid; grid-template-columns: repeat(3, minmax(180px, 1fr)); gap: 10px; margin-top: 12px; }
    .card { background: #fff; border: 1px solid #dbe2ea; border-radius: 10px; padding: 12px; }
    .k { color: #6b7280; font-size: 12px; text-transform: uppercase; letter-spacing: 0.4px; }
    .v { font-size: 22px; font-weight: 700; margin-top: 6px; }
    table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #dbe2ea; border-radius: 10px; overflow: hidden; }
    th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid #eef2f7; }
    th { background: #f2f6fb; }
    .foot { margin-top: 12px; color: #6b7280; font-size: 12px; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <h2>Angular_NF_API_Testing - Fund Profile API</h2>
      <div class="status $statusClass">Status: $statusText</div>
      <div>Generated at: $generatedAt</div>
    </div>

    <div class="grid">
      <div class="card"><div class="k">Iterations</div><div class="v">$iterationsTotal</div><div>Failed: $iterationsFailed</div></div>
      <div class="card"><div class="k">Requests</div><div class="v">$requestsTotal</div><div>Failed: $requestsFailed</div></div>
      <div class="card"><div class="k">Assertions</div><div class="v">$assertionsTotal</div><div>Failed: $assertionsFailed</div></div>
      <div class="card"><div class="k">Pass Rate</div><div class="v">$passPercent%</div></div>
      <div class="card"><div class="k">Duration</div><div class="v">$durationSec s</div></div>
      <div class="card"><div class="k">JSON Source</div><div class="v" style="font-size: 14px;">$([System.Net.WebUtility]::HtmlEncode($JsonPath))</div></div>
    </div>

    <h3>Failures</h3>
    <table>
      <thead><tr><th>Request</th><th>Error</th></tr></thead>
      <tbody>
$failureRows
      </tbody>
    </table>

    <div class="foot">Generated by scripts/post-run-actions.ps1</div>
  </div>
</body>
</html>
"@

    $htmlDir = Split-Path -Parent $HtmlPath
    if ($htmlDir -and -not (Test-Path -LiteralPath $htmlDir)) {
        New-Item -ItemType Directory -Path $htmlDir -Force | Out-Null
    }

    Set-Content -LiteralPath $HtmlPath -Value $html -Encoding UTF8
    Write-Host "HTML report generated: $HtmlPath"
}

function New-XlsxReportFromJson {
    param(
        [string]$JsonPath,
        [string]$XlsxPath,
        [string]$CollectionPathArg
    )

    if (-not (Test-Path -LiteralPath $JsonPath)) {
        throw "JSON report not found: $JsonPath"
    }

    $scriptPath = Join-Path $PSScriptRoot "generate-xlsx-report.js"
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        throw "XLSX generator script not found: $scriptPath"
    }

    $args = @(
        $scriptPath,
        "--json", $JsonPath,
        "--xlsx", $XlsxPath,
        "--collection", $CollectionPathArg
    )

    & node @args
    if ($LASTEXITCODE -ne 0) {
        throw "XLSX generation failed with exit code $LASTEXITCODE"
    }

    Write-Host "XLSX report generated: $XlsxPath"
}

function Send-ExecutionMail {
    param(
        [int]$ExitCode
    )

    $status = if ($ExitCode -eq 0) { "SUCCESS" } else { "FAILED" }
    $endTime = (Get-Date).ToString("ddd MM/dd/yyyy HH:mm:ss.ff")

    $subject = "$SubjectPrefix $status | Fund Profile API"
    $attachments = @()
    if ($AttachLogFile -and $LogFile -and (Test-Path -LiteralPath $LogFile)) {
        $attachments += $LogFile
    }
    if ($HtmlReport -and (Test-Path -LiteralPath $HtmlReport)) {
        $attachments += $HtmlReport
    }
    if ($JsonReport -and (Test-Path -LiteralPath $JsonReport)) {
        $attachments += $JsonReport
    }
    if ($XlsxReport -and (Test-Path -LiteralPath $XlsxReport)) {
        $attachments += $XlsxReport
    }

    $attachmentNames = @($attachments | ForEach-Object { Split-Path -Leaf $_ })
    if ($attachmentNames.Count -eq 0) {
        $attachmentLabel = "No report attachments available"
    }
    else {
        $attachmentLabel = $attachmentNames -join ", "
    }

    $bodyLines = @(
        "Angular_NF_API_Testing - Fund Profile API Execution",
        "",
        "Status   : $status",
        "ExitCode : $ExitCode",
        "Start    : $StartTime",
        "End      : $endTime",
        "",
        "Log File : $LogFile",
        "HTML     : $HtmlReport",
        "JSON     : $JsonReport",
        "XLSX     : $XlsxReport",
        "Attached Reports: $attachmentLabel"
    )

    $htmlBody = @"
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: Segoe UI, Arial, sans-serif; color: #1f2937; margin: 0; padding: 0; background: #f8fafc; }
    .container { max-width: 860px; margin: 0 auto; background: #ffffff; padding: 24px; }
    h1 { margin: 0 0 18px; font-size: 20px; color: #111827; }
    table { width: 100%; border-collapse: collapse; margin: 0 0 12px; }
    th, td { font-size: 13px; line-height: 1.4; padding: 8px 10px; border: 1px solid #e5e7eb; text-align: left; vertical-align: top; }
    th { width: 34%; background: #f3f4f6; color: #111827; font-weight: 600; }
    td { background: #ffffff; color: #1f2937; }
    .result-ok th, .result-ok td { background: #ecfdf5; color: #065f46; font-weight: 700; }
    .result-bad th, .result-bad td { background: #fef2f2; color: #991b1b; font-weight: 700; }
    .footer { margin-top: 16px; font-size: 12px; color: #6b7280; }
  </style>
</head>
<body>
  <div class="container">
    <h1>NW Interstellar API Automation - Execution Summary</h1>
    <table role="presentation">
      <tbody>
        <tr class="$(if ($status -eq 'SUCCESS') { 'result-ok' } else { 'result-bad' })"><th>Result</th><td>$status</td></tr>
        <tr><th>Generated At</th><td>$endTime</td></tr>
        <tr><th>Start Time</th><td>$StartTime</td></tr>
        <tr><th>Exit Code</th><td>$ExitCode</td></tr>
        <tr><th>Log File</th><td>$LogFile</td></tr>
        <tr><th>HTML Report</th><td>$HtmlReport</td></tr>
        <tr><th>JSON Report</th><td>$JsonReport</td></tr>
        <tr><th>XLSX Report</th><td>$XlsxReport</td></tr>
        <tr><th>Attached Reports</th><td>$attachmentLabel</td></tr>
      </tbody>
    </table>
    <div class="footer">This is an automated message from NW Interstellar API Automation.</div>
  </div>
</body>
</html>
"@

    $sendParams = @{
        To         = $To
        From       = $From
        Subject    = $subject
        Body       = $htmlBody
        BodyAsHtml = $true
        SmtpServer = $SmtpServer
        Port       = $SmtpPort
    }

    if (-not [string]::IsNullOrWhiteSpace($Cc)) {
        $ccRecipients = ($Cc -split '[;,]' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($ccRecipients.Count -gt 0) {
            $sendParams.Cc = ($ccRecipients -join ',')
        }
    }

    $useSslBool = Convert-ToBool -Value $UseSsl -DefaultValue $false
    if ($useSslBool) {
        $sendParams.UseSsl = $true
    }

    if ($attachments.Count -gt 0) {
        $sendParams.Attachments = $attachments
    }

    if ($SmtpUsername -and $SmtpPassword) {
        $secure = ConvertTo-SecureString $SmtpPassword -AsPlainText -Force
        $credential = New-Object System.Management.Automation.PSCredential($SmtpUsername, $secure)
        $sendParams.Credential = $credential
    }

    Send-MailMessage @sendParams
    Write-Host "Email notification sent to: $To"
}

$finalExitCode = [int]$BaseExitCode

if ($finalExitCode -eq 0) {
    if (-not (Test-Path -LiteralPath $JsonReport)) {
        $finalExitCode = 2
        Write-Error "JSON report missing: $JsonReport"
    }
}

if ($finalExitCode -eq 0) {
    try {
        New-HtmlReportFromJson -JsonPath $JsonReport -HtmlPath $HtmlReport
        if (-not (Test-Path -LiteralPath $HtmlReport)) {
            $finalExitCode = 3
            Write-Error "HTML report missing after generation: $HtmlReport"
        }

        if ($finalExitCode -eq 0) {
            New-XlsxReportFromJson -JsonPath $JsonReport -XlsxPath $XlsxReport -CollectionPathArg $CollectionPath
            if (-not (Test-Path -LiteralPath $XlsxReport)) {
                $finalExitCode = 5
                Write-Error "XLSX report missing after generation: $XlsxReport"
            }
        }
    }
    catch {
        if ($finalExitCode -eq 0) {
            $finalExitCode = 4
        }
        Write-Error $_
    }
}

$mailEnabledBool = Convert-ToBool -Value $MailEnabled -DefaultValue $false
if ($mailEnabledBool) {
    if ([string]::IsNullOrWhiteSpace($SmtpServer) -or [string]::IsNullOrWhiteSpace($From) -or [string]::IsNullOrWhiteSpace($To)) {
        Write-Warning "Email skipped: set SMTP server, From, and To values."
    }
    else {
        try {
            Send-ExecutionMail -ExitCode $finalExitCode
        }
        catch {
            Write-Warning "Failed to send email notification: $($_.Exception.Message)"
        }
    }
}

exit $finalExitCode
