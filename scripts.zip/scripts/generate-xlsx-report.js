const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

function getArgValue(flag) {
  const index = process.argv.indexOf(flag);
  if (index === -1 || index + 1 >= process.argv.length) {
    return undefined;
  }
  return process.argv[index + 1];
}

function toUniqueWorksheetName(rawName, usedNames) {
  const base = String(rawName || 'Sheet')
    .replace(/[\\/:?*\[\]]/g, '')
    .trim() || 'Sheet';

  let name = base.slice(0, 31);
  let suffix = 1;

  while (usedNames.has(name.toLowerCase())) {
    const suffixText = `_${suffix}`;
    const allowed = Math.max(1, 31 - suffixText.length);
    name = `${base.slice(0, allowed)}${suffixText}`;
    suffix += 1;
  }

  usedNames.add(name.toLowerCase());
  return name;
}

function getResponseBodyText(execution) {
  if (!execution || !execution.response) {
    return null;
  }

  const stream = execution.response.stream;
  if (Buffer.isBuffer(stream)) {
    return stream.toString('utf8');
  }

  if (Array.isArray(stream)) {
    return Buffer.from(stream).toString('utf8');
  }

  if (typeof stream === 'string') {
    return stream;
  }

  if (stream && typeof stream.toString === 'function') {
    return stream.toString('utf8');
  }

  return null;
}

function detectResponseDataState(execution) {
  const responseBody = getResponseBodyText(execution);
  if (responseBody === null || typeof responseBody === 'undefined') {
    return '';
  }

  const trimmedBody = String(responseBody).trim();
  if (!trimmedBody) {
    return 'Empty';
  }

  try {
    const parsedBody = JSON.parse(trimmedBody);
    if (parsedBody === null) {
      return 'Null';
    }

    if (
      parsedBody
      && typeof parsedBody === 'object'
      && Object.prototype.hasOwnProperty.call(parsedBody, 'data')
      && parsedBody.data === null
    ) {
      return 'Null';
    }
  } catch (_error) {
    return '';
  }

  return '';
}

function getExecutionResultStatus(responseCode, responseDataState) {
  const statusCode = Number(responseCode);
  const dataState = String(responseDataState || '').trim().toLowerCase();
  return statusCode === 200 ? 'Pass' : 'Fail';
}

function calculateDataStateCounts(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  let nullCount = 0;
  let emptyCount = 0;

  safeRows.forEach((row) => {
    const state = String((row && row.responseDataState) || '').trim().toLowerCase();
    if (state === 'null') {
      nullCount += 1;
    } else if (state === 'empty') {
      emptyCount += 1;
    }
  });

  return {
    nullCount,
    emptyCount,
    total: nullCount + emptyCount
  };
}

function calculateResultCounts(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  let passCount = 0;
  let failCount = 0;

  safeRows.forEach((row) => {
    const value = String((row && row.result) || '').trim().toLowerCase();
    if (value === 'pass') {
      passCount += 1;
    } else if (value === 'fail') {
      failCount += 1;
    }
  });

  return {
    passCount,
    failCount,
    total: passCount + failCount
  };
}

function getTickerFromExecution(execution) {
  const requestUrl = execution && execution.request && execution.request.url;
  if (!requestUrl) {
    return '';
  }

  let raw = '';
  if (typeof requestUrl === 'string') {
    raw = requestUrl;
  } else if (requestUrl.raw) {
    raw = String(requestUrl.raw);
  } else if (typeof requestUrl.toString === 'function') {
    raw = requestUrl.toString();
  }

  const match = raw.match(/\/funds\/([^/?]+)/i);
  return match ? decodeURIComponent(match[1]) : '';
}

function readCollectionName(collectionPath) {
  if (!collectionPath || !fs.existsSync(collectionPath)) {
    return 'Fund Profile API';
  }

  try {
    const raw = fs.readFileSync(collectionPath, 'utf8');
    const text = raw.charCodeAt(0) === 0xfeff ? raw.slice(1) : raw;
    const json = JSON.parse(text);
    if (json && json.info && json.info.name) {
      return String(json.info.name);
    }
  } catch (_err) {
    return 'Fund Profile API';
  }

  return 'Fund Profile API';
}

function normalizeExecutionRow(row, fallbackCollectionName) {
  const responseCode = typeof row.responseCode !== 'undefined' ? row.responseCode : '';
  const responseDataState = typeof row.responseDataState !== 'undefined' ? row.responseDataState : '';
  const resolvedCollection = String(row.collection || fallbackCollectionName || 'Collection').trim() || 'Collection';

  return {
    collection: resolvedCollection,
    requestName: row.requestName || '',
    ticker: row.ticker || '',
    responseCode,
    responseStatus: row.responseStatus || '',
    responseTimeMs: typeof row.responseTimeMs !== 'undefined' ? row.responseTimeMs : '',
    responseDataState,
    result: getExecutionResultStatus(responseCode, responseDataState)
  };
}

function buildOverviewRowsForCollections(rows) {
  const grouped = new Map();
  (Array.isArray(rows) ? rows : []).forEach((row) => {
    const key = String(row.collection || 'Collection').trim() || 'Collection';
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key).push(row);
  });

  return Array.from(grouped.entries()).map(([collection, collectionRows]) => {
    const resultCounts = calculateResultCounts(collectionRows);
    const dataStateCounts = calculateDataStateCounts(collectionRows);
    return {
      collection,
      status: resultCounts.failCount === 0 ? 'PASS' : 'FAIL',
      requests: collectionRows.length,
      assertions: '',
      failedAssertions: '',
      passCount: resultCounts.passCount,
      failCount: resultCounts.failCount,
      failures: resultCounts.failCount,
      nullDataResponses: dataStateCounts.nullCount,
      emptyDataResponses: dataStateCounts.emptyCount
    };
  });
}

function groupRowsByCollection(rows) {
  const grouped = new Map();
  (Array.isArray(rows) ? rows : []).forEach((row) => {
    const key = String(row.collection || 'Collection').trim() || 'Collection';
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key).push(row);
  });
  return grouped;
}

function main() {
  const jsonPath = getArgValue('--json');
  const xlsxPath = getArgValue('--xlsx');
  const collectionPathArg = getArgValue('--collection');

  if (!jsonPath || !xlsxPath) {
    console.error('Usage: node generate-xlsx-report.js --json <jsonPath> --xlsx <xlsxPath> [--collection <collectionPath>]');
    process.exit(2);
  }

  if (!fs.existsSync(jsonPath)) {
    console.error(`JSON report not found: ${jsonPath}`);
    process.exit(3);
  }

  const raw = fs.readFileSync(jsonPath, 'utf8');
  const text = raw.charCodeAt(0) === 0xfeff ? raw.slice(1) : raw;
  const report = JSON.parse(text);

  const collectionPath = collectionPathArg
    ? path.resolve(process.cwd(), collectionPathArg)
    : '';
  const collectionName = readCollectionName(collectionPath);
  let executionRows = [];
  let overviewRows = [];

  if (Array.isArray(report.executionRows)) {
    executionRows = report.executionRows.map((row) => normalizeExecutionRow(row || {}, collectionName));

    if (Array.isArray(report.overview) && report.overview.length > 0) {
      overviewRows = report.overview.map((row) => {
        const failCount = typeof row.failCount !== 'undefined' ? Number(row.failCount) : NaN;
        const computedStatus = Number.isFinite(failCount) ? (failCount > 0 ? 'FAIL' : 'PASS') : (row.status || '');
        return {
          collection: row.collection || collectionName,
          status: computedStatus,
          requests: typeof row.requests !== 'undefined' ? row.requests : '',
          assertions: typeof row.assertions !== 'undefined' ? row.assertions : '',
          failedAssertions: typeof row.failedAssertions !== 'undefined' ? row.failedAssertions : '',
          passCount: typeof row.passCount !== 'undefined' ? row.passCount : '',
          failCount: typeof row.failCount !== 'undefined' ? row.failCount : '',
          failures: typeof row.failures !== 'undefined' ? row.failures : '',
          nullDataResponses: typeof row.nullDataResponses !== 'undefined' ? row.nullDataResponses : '',
          emptyDataResponses: typeof row.emptyDataResponses !== 'undefined' ? row.emptyDataResponses : ''
        };
      });
    } else {
      overviewRows = buildOverviewRowsForCollections(executionRows);
    }
  } else {
    const run = report.run || {};
    const executions = Array.isArray(run.executions) ? run.executions : [];
    const stats = run.stats || {};
    const failures = Array.isArray(run.failures) ? run.failures.length : 0;

    executionRows = executions.map((execution) => {
      const requestName = execution && execution.item && execution.item.name
        ? String(execution.item.name)
        : '';
      const ticker = getTickerFromExecution(execution);
      const responseCode = execution && execution.response && typeof execution.response.code !== 'undefined'
        ? execution.response.code
        : '';
      const responseStatus = execution && execution.response && execution.response.status
        ? execution.response.status
        : '';
      const responseTimeMs = execution && execution.response && typeof execution.response.responseTime !== 'undefined'
        ? execution.response.responseTime
        : '';
      const responseDataState = detectResponseDataState(execution);
      const result = getExecutionResultStatus(responseCode, responseDataState);

      return {
        collection: collectionName,
        requestName,
        ticker,
        responseCode,
        responseStatus,
        responseTimeMs,
        responseDataState,
        result
      };
    });

    const resultCounts = calculateResultCounts(executionRows);
    const dataStateCounts = calculateDataStateCounts(executionRows);
    const requests = stats.requests || {};
    const assertions = stats.assertions || {};

    overviewRows = [{
      collection: collectionName,
      status: (Number(assertions.failed || 0) === 0 && Number(failures) === 0) ? 'PASS' : 'FAIL',
      requests: Number(requests.total || 0),
      assertions: Number(assertions.total || 0),
      failedAssertions: Number(assertions.failed || 0),
      passCount: resultCounts.passCount,
      failCount: resultCounts.failCount,
      failures: Number(failures || 0),
      nullDataResponses: dataStateCounts.nullCount,
      emptyDataResponses: dataStateCounts.emptyCount
    }];
  }

  const rowsByCollection = groupRowsByCollection(executionRows);

  const workbook = xlsx.utils.book_new();
  const usedSheetNames = new Set();

  xlsx.utils.book_append_sheet(
    workbook,
    xlsx.utils.json_to_sheet(overviewRows),
    toUniqueWorksheetName('Overview', usedSheetNames)
  );

  const failedApiByTicker = new Map();
  executionRows
    .filter((row) => String(row.result || '').toLowerCase() === 'fail')
    .forEach((row) => {
      const api = row.collection || row.requestName || 'Unknown API';
      if (!failedApiByTicker.has(api)) failedApiByTicker.set(api, new Set());
      failedApiByTicker.get(api).add(row.ticker || 'Unknown');
    });

  xlsx.utils.book_append_sheet(
    workbook,
    xlsx.utils.json_to_sheet(
      failedApiByTicker.size > 0
        ? Array.from(failedApiByTicker.entries()).map(([api, tickers]) => ({
            collection: api,
            failingTickers: Array.from(tickers).join(', ')
          }))
        : [{ message: 'No API failures detected.' }]
    ),
    toUniqueWorksheetName('Failed API', usedSheetNames)
  );

  xlsx.utils.book_append_sheet(
    workbook,
    xlsx.utils.json_to_sheet(executionRows),
    toUniqueWorksheetName('Consolidated', usedSheetNames)
  );

  Array.from(rowsByCollection.entries()).forEach(([collectionKey, rows]) => {
    const sheetRows = rows.length > 0
      ? rows.map((row) => ({
        requestName: row.requestName,
        ticker: row.ticker,
        responseCode: row.responseCode,
        responseStatus: row.responseStatus,
        responseTimeMs: row.responseTimeMs,
        responseDataState: row.responseDataState,
        result: row.result
      }))
      : [{ message: 'No execution rows captured for this collection.' }];

    xlsx.utils.book_append_sheet(
      workbook,
      xlsx.utils.json_to_sheet(sheetRows),
      toUniqueWorksheetName(collectionKey, usedSheetNames)
    );
  });

  const outDir = path.dirname(path.resolve(xlsxPath));
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  xlsx.writeFile(workbook, xlsxPath);
  console.log(`XLSX report generated: ${xlsxPath}`);
}

main();
