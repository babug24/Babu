param(
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
  [string]$DataFile = "ticker.csv",
  [switch]$HideReportSecrets,
  [string]$ArchiveReports = "true"
)

$ErrorActionPreference = "Stop"

function ConvertTo-BoolValue {
  param(
    [string]$Value,
    [bool]$DefaultValue = $true
  )

  if ([string]::IsNullOrWhiteSpace($Value)) {
    return $DefaultValue
  }

  switch ($Value.Trim().ToLowerInvariant()) {
    "1" { return $true }
    "true" { return $true }
    "yes" { return $true }
    "y" { return $true }
    "0" { return $false }
    "false" { return $false }
    "no" { return $false }
    "n" { return $false }
    default {
      throw "Invalid value for ArchiveReports: '$Value'. Use true/false or 1/0."
    }
  }
}

$archiveReportsEnabled = ConvertTo-BoolValue -Value $ArchiveReports -DefaultValue $true

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$reportsRoot = Join-Path $ProjectRoot "reports"
$schedulerReportsRoot = Join-Path $reportsRoot "scheduler"
$intermediateLatestArtifacts = @(
  (Join-Path $reportsRoot "newman-report-latest.html"),
  (Join-Path $reportsRoot "newman-junit-latest.xml"),
  (Join-Path $reportsRoot "newman-run-latest.json"),
  (Join-Path $reportsRoot "newman-summary-latest.json"),
  (Join-Path $reportsRoot "newman-response-codes-latest.csv")
)

if (-not (Test-Path $schedulerReportsRoot)) {
  New-Item -ItemType Directory -Path $schedulerReportsRoot -Force | Out-Null
}

$stdoutLog = Join-Path $schedulerReportsRoot "full-run-$timestamp.out.log"
$stderrLog = Join-Path $schedulerReportsRoot "full-run-$timestamp.err.log"
$summaryLog = Join-Path $schedulerReportsRoot "full-run-$timestamp.summary.json"

function Get-LatestTimestampedReportPath {
  param(
    [string]$ReportsRoot,
    [string]$Extension
  )

  $pattern = "API_Response_report_*.$Extension"
  $items = Get-ChildItem -Path $ReportsRoot -Filter $pattern -File -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending

  if ($items -and $items.Count -gt 0) {
    return $items[0].FullName
  }

  return $null
}

Push-Location $ProjectRoot
try {
  foreach ($artifact in $intermediateLatestArtifacts) {
    if (Test-Path $artifact) {
      Remove-Item -Path $artifact -Force -ErrorAction SilentlyContinue
    }
  }

  $previousNativeErrorPreference = $null
  $hasNativeErrorPreference = $false
  if (Get-Variable -Name PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue) {
    $hasNativeErrorPreference = $true
    $previousNativeErrorPreference = $PSNativeCommandUseErrorActionPreference
    # Allow native stderr output (warnings) without terminating the script.
    $PSNativeCommandUseErrorActionPreference = $false
  }
  $previousErrorActionPreference = $ErrorActionPreference

  $nodeArgs = @(
    "scripts/run-collection.js",
    "--collection", "all",
    "--data", $DataFile,
    "--archive-reports", ($archiveReportsEnabled.ToString().ToLower())
  )

  if ($HideReportSecrets.IsPresent) {
    $nodeArgs += @("--hide-report-secrets", "true")
  }

  Write-Host "Starting full collection run..."
  Write-Host "ProjectRoot: $ProjectRoot"
  Write-Host "DataFile: $DataFile"
  Write-Host "StdOut log: $stdoutLog"
  Write-Host "StdErr log: $stderrLog"

  $ErrorActionPreference = "Continue"
  & node @nodeArgs 1> $stdoutLog 2> $stderrLog
  $ErrorActionPreference = $previousErrorActionPreference
  $exitCode = $LASTEXITCODE

  if ($hasNativeErrorPreference) {
    $PSNativeCommandUseErrorActionPreference = $previousNativeErrorPreference
  }

  foreach ($artifact in $intermediateLatestArtifacts) {
    if (Test-Path $artifact) {
      Remove-Item -Path $artifact -Force -ErrorAction SilentlyContinue
    }
  }

  $consolidatedHtmlPath = Get-LatestTimestampedReportPath -ReportsRoot $reportsRoot -Extension "html"
  $consolidatedXlsxPath = Get-LatestTimestampedReportPath -ReportsRoot $reportsRoot -Extension "xlsx"
  $consolidatedJsonPath = Get-LatestTimestampedReportPath -ReportsRoot $reportsRoot -Extension "json"
  $consolidatedCsvPath = Get-LatestTimestampedReportPath -ReportsRoot $reportsRoot -Extension "csv"

  $summary = [ordered]@{
    timestamp = (Get-Date).ToString("o")
    projectRoot = $ProjectRoot
    command = "node $($nodeArgs -join ' ')"
    exitCode = $exitCode
    status = if ($exitCode -eq 0) { "Success" } else { "Failed" }
    dataFile = $DataFile
    stdoutLog = $stdoutLog
    stderrLog = $stderrLog
    consolidatedHtml = $consolidatedHtmlPath
    consolidatedXlsx = $consolidatedXlsxPath
    consolidatedJson = $consolidatedJsonPath
    consolidatedCsv = $consolidatedCsvPath
  }

  $summary | ConvertTo-Json -Depth 4 | Set-Content -Path $summaryLog -Encoding UTF8

  Write-Host "Summary log: $summaryLog"
  exit $exitCode
}
finally {
  if (Get-Variable -Name hasNativeErrorPreference -ErrorAction SilentlyContinue) {
    if ($hasNativeErrorPreference) {
      $PSNativeCommandUseErrorActionPreference = $previousNativeErrorPreference
    }
  }
  if (Get-Variable -Name previousErrorActionPreference -ErrorAction SilentlyContinue) {
    $ErrorActionPreference = $previousErrorActionPreference
  }
  Pop-Location
}
