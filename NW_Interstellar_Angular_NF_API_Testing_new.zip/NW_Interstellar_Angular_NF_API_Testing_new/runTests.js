const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { parse } = require('csv-parse/sync');
const Ajv = require('ajv');
const ejs = require('ejs');
const ExcelJS = require('exceljs');
const nodemailer = require('nodemailer');

// ---------- Configuration ----------
const CONFIG_FILE = 'config.json';
const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
const args = process.argv.slice(2);
function getArgValue(name) {
  const index = args.indexOf(name);
  return index >= 0 && index < args.length - 1 ? args[index + 1] : null;
}
const cliEnvironment = getArgValue('--env') || getArgValue('-e');
const currentEnvironment = cliEnvironment || process.env.TEST_ENV || config.global.environment || 'prod';
const envConfig = config.global.environments?.[currentEnvironment] || {};
console.log(`Running tests for environment: ${currentEnvironment} (available: ${Object.keys(config.global.environments || {}).join(', ')})`);
if (cliEnvironment && !config.global.environments?.[cliEnvironment]) {
  console.warn(`Warning: environment '${cliEnvironment}' is not defined in config.json. Falling back to default '${config.global.environment || 'prod'}'.`);
}

// ---------- Helpers ----------
function getTickers(collection) {
  if (collection.tickerFile) {
    const content = fs.readFileSync(collection.tickerFile, 'utf8');
    const records = parse(content, { skip_empty_lines: true, trim: true });
    return records.flat().filter(t => t && t.length > 0);
  }
  if (collection.tickers) {
    return collection.tickers;
  }
  return [''];
}

function buildUrl(base, endpoint, ticker, variables = {}) {
  let url = endpoint;
  if (!/^https?:\/\//i.test(endpoint)) {
    if (!base) {
      throw new Error(`No baseUrl configured for endpoint ${endpoint}`);
    }
    url = base + endpoint;
  }
  url = url.replace(/{ticker}|{fundcode}/g, ticker);
  for (const [key, value] of Object.entries(variables)) {
    url = url.replace(new RegExp(`{${key}}`, 'g'), value);
  }
  return url;
}

// ---------- Access Code Pre-request ----------
async function fetchAccessCode(preReqConfig, variables = {}) {
  if (!preReqConfig) return {};
  if (preReqConfig.type === 'accessCode') {
    try {
      let url = preReqConfig.url;
      for (const [key, value] of Object.entries(variables)) {
        url = url.replace(new RegExp(`{${key}}`, 'g'), value);
      }
      const resp = await axios({
        method: 'GET',
        url,
        headers: preReqConfig.headers || {},
        timeout: config.global.timeout || 10000
      });
      const code = resp.data.accessCode || resp.data.status?.accessCode;
      if (!code) throw new Error('Access code not found in response');
      return { accesscode: code };
    } catch (err) {
      console.error('Failed to fetch access code:', err.message);
      throw err;
    }
  }
  return {};
}

// ---------- Response Validation ----------
function validateResponse(response, rules, ticker, config) {
  const errors = [];
  const { status, data, headers, config: reqConfig } = response;
  const responseTime = response.duration;

  // Status
  if (status !== rules.expectedStatus) {
    errors.push(`Expected status ${rules.expectedStatus}, got ${status}`);
  }

  // Response time
  const threshold = rules.responseTimeThreshold || config.global.responseTimeThresholdMs || 3000;
  if (responseTime > threshold) {
    errors.push(`Response time ${responseTime}ms > ${threshold}ms`);
  }

  // Empty data check (assuming data.data is the main container)
  if (rules.checkEmptyData) {
    const dataObj = data.data;
    if (!dataObj || (Array.isArray(dataObj) && dataObj.length === 0)) {
      const allowed = rules.allowedEmptyTickers || [];
      if (!allowed.includes(ticker)) {
        errors.push('Response data is empty but not allowed');
      }
    }
  }

  // Required fields
  if (rules.requiredFields) {
    for (const field of rules.requiredFields) {
      if (!data.hasOwnProperty(field)) {
        errors.push(`Missing required field: ${field}`);
      }
    }
  }

  // Schema validation (optional)
  if (rules.schemaFile) {
    const schema = JSON.parse(fs.readFileSync(rules.schemaFile, 'utf8'));
    const ajv = new Ajv();
    const valid = ajv.validate(schema, data);
    if (!valid) {
      errors.push(`Schema validation failed: ${ajv.errorsText()}`);
    }
  }

  return errors;
}

// ---------- Execute Single Request ----------
async function executeRequest(collection, ticker, variables = {}) {
  const baseUrl = collection.baseUrl || envConfig.baseUrl;
  const url = buildUrl(baseUrl, collection.endpoint, ticker, variables);
  const headers = {
    ...config.global.defaultHeaders,
    ...envConfig.defaultHeaders,
    ...collection.headers
  };
  const method = collection.method || 'GET';
  const timeout = config.global.timeout || 10000;
  const start = Date.now();

  try {
    const response = await axios({
      method,
      url,
      headers,
      timeout
    });
    const duration = Date.now() - start;
    response.duration = duration;
    const errors = validateResponse(response, collection.validationRules, ticker, config);
    return {
      ticker,
      responseCode: response.status,
      responseStatus: response.statusText,
      responseTimeMs: duration,
      responseDataState: (response.data.data && Array.isArray(response.data.data) && response.data.data.length === 0) ? 'Empty' : '',
      result: errors.length === 0 ? 'Pass' : 'Fail',
      errors
    };
  } catch (err) {
    let status = 'ERROR';
    let code = 'N/A';
    if (err.response) {
      status = err.response.statusText || 'Error';
      code = err.response.status;
    }
    return {
      ticker,
      responseCode: code,
      responseStatus: status,
      responseTimeMs: Date.now() - start,
      responseDataState: '',
      result: 'Fail',
      errors: [err.message]
    };
  }
}

// ---------- Run a Collection ----------
async function runCollection(collection) {
  const tickers = getTickers(collection);
  console.log(`  → ${collection.name} (${tickers.length} tickers)`);

  const collectionVariables = collection.variables || {};
  let variables = { ...collectionVariables };

  if (collection.preRequest) {
    const preReqVariables = { ...collectionVariables };
    preReqVariables.morningstarApiKey = process.env.MORNINGSTAR_API_KEY || envConfig.morningstarApiKey;
    const preReqResult = await fetchAccessCode(collection.preRequest, preReqVariables);
    variables = { ...collectionVariables, ...preReqResult };
  }

  const results = [];
  // Sequential (or you can use parallel with concurrency control)
  for (const ticker of tickers) {
    const result = await executeRequest(collection, ticker, variables);
    results.push(result);
  }
  return {
    collectionName: collection.name,
    results
  };
}

// ---------- Main ----------
async function runAll() {
  const allResults = [];
  for (const collection of config.collections) {
    const collResult = await runCollection(collection);
    allResults.push(collResult);
  }
  return allResults;
}

// ---------- Report Generation ----------
function getReportFilenameBase() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  return `API_Response_report_${timestamp}`;
}

async function generateReport(results) {
  const totalRequests = results.reduce((sum, coll) => sum + coll.results.length, 0);
  const passed = results.reduce((sum, coll) => sum + coll.results.filter(r => r.result === 'Pass').length, 0);
  const failed = totalRequests - passed;
  const passRate = totalRequests ? ((passed / totalRequests) * 100).toFixed(2) : 0;
  const generatedAt = new Date().toISOString();
  const baseName = getReportFilenameBase();
  const reportsDir = path.join(process.cwd(), 'reports');
  if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir, { recursive: true });
  }

  // HTML report
  const template = fs.readFileSync('reportTemplate.ejs', 'utf8');
  const html = ejs.render(template, {
    results,
    totalRequests,
    passed,
    failed,
    passRate,
    generatedAt
  });
  const htmlPath = path.join(reportsDir, `${baseName}.html`);
  fs.writeFileSync(htmlPath, html, 'utf8');

  // JSON report
  const jsonReport = {
    generatedAt,
    totalRequests,
    passed,
    failed,
    passRate: Number(passRate),
    results
  };
  const jsonPath = path.join(reportsDir, `${baseName}.json`);
  fs.writeFileSync(jsonPath, JSON.stringify(jsonReport, null, 2), 'utf8');

  // XLSX report
  const workbook = new ExcelJS.Workbook();
  const summarySheet = workbook.addWorksheet('Summary');
  summarySheet.columns = [
    { header: 'Metric', key: 'metric', width: 24 },
    { header: 'Value', key: 'value', width: 20 }
  ];
  summarySheet.addRows([
    { metric: 'Generated At', value: generatedAt },
    { metric: 'Total Requests', value: totalRequests },
    { metric: 'Passed', value: passed },
    { metric: 'Failed', value: failed },
    { metric: 'Pass Rate', value: `${passRate}%` }
  ]);
  summarySheet.getRow(1).font = { bold: true };

  const detailsSheet = workbook.addWorksheet('Details');
  detailsSheet.columns = [
    { header: 'Collection', key: 'collection', width: 32 },
    { header: 'Ticker', key: 'ticker', width: 20 },
    { header: 'Status Code', key: 'responseCode', width: 16 },
    { header: 'Status', key: 'responseStatus', width: 20 },
    { header: 'Response Time (ms)', key: 'responseTimeMs', width: 18 },
    { header: 'Data State', key: 'responseDataState', width: 14 },
    { header: 'Result', key: 'result', width: 12 },
    { header: 'Errors', key: 'errors', width: 80 }
  ];

  for (const coll of results) {
    for (const r of coll.results) {
      detailsSheet.addRow({
        collection: coll.collectionName,
        ticker: r.ticker,
        responseCode: r.responseCode,
        responseStatus: r.responseStatus,
        responseTimeMs: r.responseTimeMs,
        responseDataState: r.responseDataState || '',
        result: r.result,
        errors: r.errors ? r.errors.join('; ') : ''
      });
    }
  }
  detailsSheet.getRow(1).font = { bold: true };

  const xlsxPath = path.join(reportsDir, `${baseName}.xlsx`);
  await workbook.xlsx.writeFile(xlsxPath);

  console.log(`✅ Reports generated: ${htmlPath}, ${jsonPath}, ${xlsxPath}`);
  return {
    generatedAt,
    totalRequests,
    passed,
    failed,
    passRate: Number(passRate),
    htmlPath,
    jsonPath,
    xlsxPath
  };
}

function getEmailConfig() {
  const emailConfig = config.global.email || {};
  const smtpConfig = emailConfig.smtp || {};
  return {
    enabled: emailConfig.enabled === true,
    host: process.env.SMTP_HOST || smtpConfig.host,
    port: Number(process.env.SMTP_PORT || smtpConfig.port || 587),
    secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE.toLowerCase() === 'true' : smtpConfig.secure || false,
    auth: {
      user: process.env.SMTP_USER || smtpConfig.auth?.user,
      pass: process.env.SMTP_PASS || smtpConfig.auth?.pass
    },
    from: process.env.EMAIL_FROM || emailConfig.from,
    to: process.env.EMAIL_TO ? process.env.EMAIL_TO.split(',').map(s => s.trim()) : emailConfig.to,
    subject: process.env.EMAIL_SUBJECT || emailConfig.subject || `API Test Report ${new Date().toLocaleString()}`
  };
}

async function sendReportEmail(reportInfo) {
  const emailConfig = getEmailConfig();
  if (!emailConfig.enabled) {
    console.log('✉️ Email not sent: email.enabled is false.');
    return;
  }

  const required = emailConfig.host && emailConfig.auth.user && emailConfig.auth.pass && emailConfig.from && emailConfig.to?.length;
  if (!required) {
    console.log('✉️ Email not sent: SMTP/email settings are missing or incomplete.');
    return;
  }

  const transporter = nodemailer.createTransport({
    host: emailConfig.host,
    port: emailConfig.port,
    secure: emailConfig.secure,
    auth: emailConfig.auth
  });

  const summaryText = `API automation report generated at ${reportInfo.generatedAt}\nTotal: ${reportInfo.totalRequests}\nPassed: ${reportInfo.passed}\nFailed: ${reportInfo.failed}\nPass Rate: ${reportInfo.passRate}%`;

  await transporter.sendMail({
    from: emailConfig.from,
    to: emailConfig.to,
    subject: emailConfig.subject,
    text: summaryText,
    html: `<p>API automation report generated at ${reportInfo.generatedAt}</p><p>Total: ${reportInfo.totalRequests}</p><p>Passed: ${reportInfo.passed}</p><p>Failed: ${reportInfo.failed}</p><p>Pass Rate: ${reportInfo.passRate}%</p>`,
    attachments: [
      { filename: path.basename(reportInfo.htmlPath), path: path.resolve(reportInfo.htmlPath) },
      { filename: path.basename(reportInfo.jsonPath), path: path.resolve(reportInfo.jsonPath) },
      { filename: path.basename(reportInfo.xlsxPath), path: path.resolve(reportInfo.xlsxPath) }
    ]
  });
  console.log('✉️ Report email sent successfully.');
}

// ---------- Run & Exit ----------
(async () => {
  try {
    const results = await runAll();
    const reportInfo = await generateReport(results);
    await sendReportEmail(reportInfo);
    // Exit with error if any test failed
    const anyFailed = results.some(coll => coll.results.some(r => r.result === 'Fail'));
    if (anyFailed) {
      console.error('❌ Some tests failed.');
      process.exit(1);
    }
    console.log('✅ All tests passed.');
    process.exit(0);
  } catch (err) {
    console.error('❌ Fatal error:', err);
    process.exit(1);
  }
})();