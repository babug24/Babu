@echo off
setlocal
cd /d "%~dp0"
echo.
echo Running npm run test:all-envs in %CD%
if not defined npm (
  if exist "%ProgramFiles%\nodejs\npm.cmd" (
    set "PATH=%ProgramFiles%\nodejs;%PATH%"
  ) else if exist "%ProgramFiles(x86)%\nodejs\npm.cmd" (
    set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
  )
)
call npm run test:all-envs
set "EXITCODE=%ERRORLEVEL%"
echo npm finished with exit code %EXITCODE%.
endlocal
exit /b %EXITCODE%
