1. Configure URLs to Test
bash
# Edit the CSV file with your target URLs
nano test-data/urls.csv

# Sample format:
url,description,priority
https://www.nationwide.com/,Nationwide homepage,high
https://www.google.com/,Google homepage,medium
https://developer.mozilla.org/,MDN Web Docs,high
https://www.w3.org/WAI/ARIA/apg/,ARIA Patterns,high

# Single column format also works:
url
https://www.example1.com/
https://www.example2.com/
2. Basic Test Commands
bash
# Run all tests
npm test

# Run with headed browser (visible)
npm run test:headed

# Run specific test file
npx playwright test tests/accessibility/accessibility-audit.spec.ts

# Run with specific grep pattern
npx playwright test --grep="scroll"
npx playwright test --grep="keyboard"

# Run with specific project (browser)
npm run test:chromium
npm run test:firefox
npm run test:webkit
3. Environment-Specific Tests
bash
# Local environment
TEST_ENV=local npm test
npm run test:local

# Staging environment
TEST_ENV=staging npm test
npm run test:staging

# Production environment
TEST_ENV=production npm test
npm run test:production

# Mobile environment
TEST_ENV=mobile npm test
npm run test:mobile

# Tablet environment
TEST_ENV=tablet npm test
4. Debug Mode
bash
# Run with visible browser and slow motion
HEADLESS=false SLOW_MO=100 npm test
npm run test:debug

# Run with specific viewport
VIEWPORT_WIDTH=1280 VIEWPORT_HEIGHT=720 npm test

# Enable Playwright debug
DEBUG=pw:api npm test
DEBUG=pw:browser npm test
DEBUG=pw:protocol npm test

# Generate trace for debugging
npx playwright test --trace on
5. Test Execution Options
bash
# Run tests sequentially (no parallel)
npx playwright test --workers=1

# Run with more retries
npx playwright test --retries=3

# Run with specific timeout
npx playwright test --timeout=120000

# Run with specific reporter
npx playwright test --reporter=html
npx playwright test --reporter=json
npx playwright test --reporter=line
npx playwright test --reporter=list

# Run tests from specific directory
npx playwright test tests/accessibility/
6. Watch Mode (Development)
bash
# Install watch mode plugin
npm install --save-dev npm-watch

# Add to package.json:
"watch": {
  "test": {
    "patterns": ["tests", "utils", "pages"],
    "extensions": "ts,js",
    "run": "npm test"
  }
}

# Run watch mode
npm run watch
Report Generation
1. Generate All Reports
bash
# Generate HTML, JSON, and CSV reports
npm run report

# Generate reports from specific test results
node scripts/generate-report.js --input=test-results/output/test-results.json

# Generate reports to custom directory
node scripts/generate-report.js --output=custom-reports/
2. Generate Specific Report Formats
bash
# HTML report only
node scripts/generate-report.js --format=html

# JSON report only
node scripts/generate-report.js --format=json

# CSV reports only
node scripts/generate-report.js --format=csv

# All formats (default)
node scripts/generate-report.js --format=all
3. View Reports
bash
# Open HTML report in default browser
npm run report:html

# On macOS
open test-results/reports/html/accessibility-report.html

# On Linux
xdg-open test-results/reports/html/accessibility-report.html

# On Windows
start test-results/reports/html/accessibility-report.html

# View Playwright's built-in report
npx playwright show-report test-results/playwright-report/
4. Report Customization
bash
# Generate report with custom title
node scripts/generate-report.js --title="My Accessibility Audit"

# Include specific test run
node scripts/generate-report.js --run-id="run-2024-01-15"

# Filter by severity
node scripts/generate-report.js --min-severity=high

# Generate report for specific URLs only
node scripts/generate-report.js --urls="example.com,google.com"

# Export to PDF (requires additional setup)
node scripts/generate-report.js --export-pdf
